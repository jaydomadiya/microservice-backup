package com.feginClient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FeginClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
