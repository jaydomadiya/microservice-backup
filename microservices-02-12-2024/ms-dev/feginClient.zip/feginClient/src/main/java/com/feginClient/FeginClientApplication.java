package com.feginClient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FeginClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(FeginClientApplication.class, args);
	}

}
